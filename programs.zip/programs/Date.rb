require 'date'

puts Date.new(2020,8,25)