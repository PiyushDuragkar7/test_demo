begin   
   x = Dir.mkdir "alreadyExist"   
   if x   
      puts "Directory created"   
   end   

end   