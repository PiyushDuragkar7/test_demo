puts (-5..-1).to_a  
puts (-5...-1).to_a       
puts ('a'..'e').to_a      
puts ('a'...'e').to_a 