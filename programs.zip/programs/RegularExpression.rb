string = "how are you 10 dog king robert morasy 12"
p string=~ /dog/    #returns index of letter which is place between the blackslashes
p string=~ /dog/? "valid" : "invalid" # ternary operator
p string.to_enum(:scan,/\d+/).map{Regexp.last_match} #d searches for integer and plus for multiple inst.
str=string.sub(/dog/,"cat")
puts #{str}