x = ["Blue", "Red", "Green", "Yellow", "White"]   
for i in x do   
  puts i   
end     