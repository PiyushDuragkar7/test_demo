module Name
RAM=2
end
puts Name::RAM