class Flim
def hero
puts "akshay"
end
end
class Director < Flim
def name
puts "raju"
end
obj=Director.new
obj.hero
end

