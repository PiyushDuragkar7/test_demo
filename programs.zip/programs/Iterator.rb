(1...5).each do |i|   
   puts i   
end   
5.times do |n|   
  puts n   
end   