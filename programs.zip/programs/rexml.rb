require 'rexml/document'   
  
include REXML   
  
file = File.new("trial.xml")   
doc = Document.new(file)   
puts docs
vsqlite3 --verions
zXSLT (Extensible Stylesheet Language Transformations)  XSLT (Extensible Stylesheet Language Transformations) is a language for transforming XML documents into other XML documents

xpath is language tto find  information  in  an xml file.

Extensible Markup Language (XML) it allows prograammeer to develop application that  can be read by other apliaction irrespective  of  os 