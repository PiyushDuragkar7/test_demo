Dir.rmdir "project"   
puts Dir.exists? "project"    