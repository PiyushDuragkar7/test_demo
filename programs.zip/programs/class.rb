class Java
def initial(name)
@name= name
puts "heloo #{@name} "
end
def show

end
obj=Java.new
obj.initial("piya")
end