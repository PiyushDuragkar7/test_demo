class Parent
def initialize
puts "this is constructor"
end
end
Parent.new


