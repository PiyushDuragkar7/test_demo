class Home
[10, 20, 30].each do |n|   
 puts n   
end
end