  Rails.application.routes.draw do

    resources :dtcs
    resources :spcps
    resources :scs
    resources :hts

    get 'consumers/pole_schedule', to: 'consumers#pole_schedule'

    resources :request_dispatches
    resources :request_requsitions, only: [:index, :new, :create, :show, :update, :destroy, :edit] do
      # get 'total_price', on: :collection
      get 'item_details', on: :collection
      get 'item_name', on: :collection
    end
    get 'dashboard', to: 'store_manager#index', as: 'store_manager/index'
    resources :items
    resources :purchase_orders
    resources :suppliers
    resources :consumers
    resources :sites, only: [:index, :new, :create, :show, :update, :destroy, :edit] do
     get 'all_contractors', on: :collection, as: 'contractors'
    end
    resources :tenders
    get 'admin_dashboard', to: 'admin#index', as: 'admin/index'
    get 'admin/users'
    get 'admin/new_user'
    post 'admin/create_user'
    delete 'admin/delete_user'
    get 'admin/edit_user'
    patch 'admin/update_user'

    get 'all_system_users', to: 'system_users#admin_index', as: 'system_users/admin_index'
    get 'system_users/new_admin'
    post 'system_users/create_admin'
    delete 'system_users/delete_admin'
    get 'system_users/edit_admin'
    patch 'system_users/update_admin'

    devise_for :system_users, path: '', path_names: {
      sign_in: 'login',
      sign_out: 'logout',
      sign_up: 'register'
      }, controllers:{
      registrations: 'system_users/registrations',
      sessions: 'system_users/sessions',
      passwords: 'system_users/passwords',
      confirmations: 'system_users/confirmations'
    }

    root 'home#index'
    get 'home/index'
    resources :orders
    #root 'orders#index'
    get 'renew/:id' => 'orders#renew'
    get 'return/:id' => 'orders#disable'
    get 'past_orders' => 'orders#old'
    # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
    get 'find_items', to: 'suppliers#find_items', as: "find_items"
    get 'find_supplier', to: 'suppliers#find_supplier', as: "find_supplier"
    post 'supplier_item_create', to: 'suppliers#supplier_item_create', as: "supplier_item_create"
    get 'item_history/:id', to: 'items#item_history', as: "item_history"
    get 'item_contractor', to: 'items#item_contractor', as: "item_contractor"
    get 'dropdown', to: 'items#dropdown', as: "dropdown"
    get 'quantity_update', to: 'request_dispatches#quantity_update', as: "quantity_update"
    get "download/:id", to: 'items#download', as: "download"
    get 'transaction_history', to: 'items#transaction_history', as: "transaction_history"
    get '/download_transaction_histroy', to: 'items#download_transaction_histroy'
    get 'change_site/:tender_id', to: 'request_requsitions#change_site', as: 'change_site' # by sumesh
    get '/consumer', to: 'consumers#index'

    get 'item_details', to: 'items#item_details', as: "item_details"
end