require "rails_helper"

RSpec.describe RequestRequsitionsController, type: :routing do
  describe "routing" do
    it "routes to #index" do
      expect(:get => "/request_requsitions").to route_to("request_requsitions#index")
    end

    it "routes to #new" do
      expect(:get => "/request_requsitions/new").to route_to("request_requsitions#new")
    end

    it "routes to #show" do
      expect(:get => "/request_requsitions/1").to route_to("request_requsitions#show", :id => "1")
    end

    it "routes to #edit" do
      expect(:get => "/request_requsitions/1/edit").to route_to("request_requsitions#edit", :id => "1")
    end


    it "routes to #create" do
      expect(:post => "/request_requsitions").to route_to("request_requsitions#create")
    end

    it "routes to #update via PUT" do
      expect(:put => "/request_requsitions/1").to route_to("request_requsitions#update", :id => "1")
    end

    it "routes to #update via PATCH" do
      expect(:patch => "/request_requsitions/1").to route_to("request_requsitions#update", :id => "1")
    end

    it "routes to #destroy" do
      expect(:delete => "/request_requsitions/1").to route_to("request_requsitions#destroy", :id => "1")
    end
  end
end
