require 'rails_helper'

RSpec.describe 'Sessions Routes', :type => :routing do
  it '/registrations to registrations#new' do
    expect(get: '/register').to route_to(
      controller: 'users/registrations',
      action: 'new'
    )
  end

  it '/sessions to sessions#new' do
    expect(get: '/login').to route_to(
      controller: 'users/sessions',
      action: 'new'
    )
  end

  it '/admin to admin#index' do
    expect(get: 'admin/index').to route_to(
      controller: 'admin',
      action: 'index'
    )
  end

  it '/admin/users to admin#users' do
    expect(get: 'admin/users').to route_to(
      controller: 'admin',
      action: 'users'
    )
  end

  it 'root page' do
    expect(get: 'home/index').to route_to(
      controller: 'home',
      action: 'index'
    )
  end
end