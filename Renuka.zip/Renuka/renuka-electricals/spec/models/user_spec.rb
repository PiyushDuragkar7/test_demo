require 'rails_helper'

RSpec.describe User, type: :model do
  context 'associations' do
    it "should belongs to role" do
      t = User.reflect_on_association(:role)
      expect(t.macro).to eq(:belongs_to)
    end
  end
end
