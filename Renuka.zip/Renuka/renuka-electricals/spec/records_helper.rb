def clean_database
  User.delete_all
end

def create_roles
  Role.create(name: 'admin')
  Role.create(name: 'store_manager')
  Role.create(name: 'contractor')
  Role.create(name: 'supervisor')
end

def create_admin_user
  user = User.create!(first_name: 'Admin', last_name: 'User', email: 'admin@gmail.com', password: '123456', role_id: Role.first.id, contact_number: 987654321, address: 'Nagpur')
  user.confirm
end

def create_supervisor_user
  user = User.create!(first_name: 'Supervisor', last_name: 'User', email: 'supervisor@gmail.com', password: '123456', role_id: Role.last.id, contact_number: 987654321, address: 'Nagpur')
  user.confirm
end