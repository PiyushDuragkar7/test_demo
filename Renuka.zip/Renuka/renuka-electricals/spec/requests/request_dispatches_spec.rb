require 'rails_helper'

RSpec.describe "RequestDispatches", type: :request do
  describe "GET /request_dispatches" do
    it "works! (now write some real specs)" do
      get request_dispatches_path
      expect(response).to have_http_status(200)
    end
  end
end
