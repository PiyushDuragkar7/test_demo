require 'rails_helper'

RSpec.describe "Tenders", type: :request do
  describe "GET /tenders" do
    it "works! (now write some real specs)" do
      get tenders_path
      expect(response).to have_http_status(200)
    end
  end
end
