require 'rails_helper'
require 'records_helper'
require 'pry'
RSpec.describe 'Sessions' do
  before(:each) do
    clean_database
    create_roles
  end

  it '#Admin Sign In' do
    sign_in create_admin_user
    get authenticated_root_path
    expect(controller.current_user).to eq(user)
  end

  it '#supervisor sign in' do
    sign_in create_supervisor_user
    get authenticated_root_path
    expect(controller.current_user).to eq(user)
  end
end
