require 'rails_helper'

RSpec.describe "purchase_orders/new", type: :view do
  before(:each) do
    assign(:purchase_order, PurchaseOrder.new(
      :order_number => "MyString",
      :item_id => 1,
      :supplier_id => 1,
      :total => 1.5
    ))
  end

  it "renders new purchase_order form" do
    render

    assert_select "form[action=?][method=?]", purchase_orders_path, "post" do

      assert_select "input[name=?]", "purchase_order[order_number]"

      assert_select "input[name=?]", "purchase_order[item_id]"

      assert_select "input[name=?]", "purchase_order[supplier_id]"

      assert_select "input[name=?]", "purchase_order[total]"
    end
  end
end
