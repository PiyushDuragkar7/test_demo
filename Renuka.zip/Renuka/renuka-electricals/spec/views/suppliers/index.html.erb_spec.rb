require 'rails_helper'

RSpec.describe "suppliers/index", type: :view do
  before(:each) do
    assign(:suppliers, [
      Supplier.create!(
        :name => "Name",
        :address => "MyText",
        :contact_person => "Contact Person",
        :contact_number => 2,
        :email => "Email"
      ),
      Supplier.create!(
        :name => "Name",
        :address => "MyText",
        :contact_person => "Contact Person",
        :contact_number => 2,
        :email => "Email"
      )
    ])
  end

  it "renders a list of suppliers" do
    render
    assert_select "tr>td", :text => "Name".to_s, :count => 2
    assert_select "tr>td", :text => "MyText".to_s, :count => 2
    assert_select "tr>td", :text => "Contact Person".to_s, :count => 2
    assert_select "tr>td", :text => 2.to_s, :count => 2
    assert_select "tr>td", :text => "Email".to_s, :count => 2
  end
end
