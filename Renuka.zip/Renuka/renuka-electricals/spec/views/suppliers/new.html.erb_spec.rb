require 'rails_helper'

RSpec.describe "suppliers/new", type: :view do
  before(:each) do
    assign(:supplier, Supplier.new(
      :name => "MyString",
      :address => "MyText",
      :contact_person => "MyString",
      :contact_number => 1,
      :email => "MyString"
    ))
  end

  it "renders new supplier form" do
    render

    assert_select "form[action=?][method=?]", suppliers_path, "post" do

      assert_select "input[name=?]", "supplier[name]"

      assert_select "textarea[name=?]", "supplier[address]"

      assert_select "input[name=?]", "supplier[contact_person]"

      assert_select "input[name=?]", "supplier[contact_number]"

      assert_select "input[name=?]", "supplier[email]"
    end
  end
end
