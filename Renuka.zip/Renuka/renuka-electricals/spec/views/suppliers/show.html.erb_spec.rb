require 'rails_helper'

RSpec.describe "suppliers/show", type: :view do
  before(:each) do
    @supplier = assign(:supplier, Supplier.create!(
      :name => "Name",
      :address => "MyText",
      :contact_person => "Contact Person",
      :contact_number => 2,
      :email => "Email"
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Name/)
    expect(rendered).to match(/MyText/)
    expect(rendered).to match(/Contact Person/)
    expect(rendered).to match(/2/)
    expect(rendered).to match(/Email/)
  end
end
