require 'rails_helper'

RSpec.describe "request_dispatches/show", type: :view do
  before(:each) do
    @request_dispatch = assign(:request_dispatch, RequestDispatch.create!(
      :request_requisition_id => 2,
      :delivery_memo_number => "Delivery Memo Number",
      :vehicle_no => "Vehicle No",
      :transporter => "Transporter"
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/2/)
    expect(rendered).to match(/Delivery Memo Number/)
    expect(rendered).to match(/Vehicle No/)
    expect(rendered).to match(/Transporter/)
  end
end
