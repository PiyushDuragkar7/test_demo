require 'rails_helper'

RSpec.describe "request_dispatches/edit", type: :view do
  before(:each) do
    @request_dispatch = assign(:request_dispatch, RequestDispatch.create!(
      :request_requisition_id => 1,
      :delivery_memo_number => "MyString",
      :vehicle_no => "MyString",
      :transporter => "MyString"
    ))
  end

  it "renders the edit request_dispatch form" do
    render

    assert_select "form[action=?][method=?]", request_dispatch_path(@request_dispatch), "post" do

      assert_select "input[name=?]", "request_dispatch[request_requisition_id]"

      assert_select "input[name=?]", "request_dispatch[delivery_memo_number]"

      assert_select "input[name=?]", "request_dispatch[vehicle_no]"

      assert_select "input[name=?]", "request_dispatch[transporter]"
    end
  end
end
