require 'rails_helper'

RSpec.describe "request_dispatches/new", type: :view do
  before(:each) do
    assign(:request_dispatch, RequestDispatch.new(
      :request_requisition_id => 1,
      :delivery_memo_number => "MyString",
      :vehicle_no => "MyString",
      :transporter => "MyString"
    ))
  end

  it "renders new request_dispatch form" do
    render

    assert_select "form[action=?][method=?]", request_dispatches_path, "post" do

      assert_select "input[name=?]", "request_dispatch[request_requisition_id]"

      assert_select "input[name=?]", "request_dispatch[delivery_memo_number]"

      assert_select "input[name=?]", "request_dispatch[vehicle_no]"

      assert_select "input[name=?]", "request_dispatch[transporter]"
    end
  end
end
