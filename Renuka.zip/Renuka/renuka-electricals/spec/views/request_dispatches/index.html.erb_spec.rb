require 'rails_helper'

RSpec.describe "request_dispatches/index", type: :view do
  before(:each) do
    assign(:request_dispatches, [
      RequestDispatch.create!(
        :request_requisition_id => 2,
        :delivery_memo_number => "Delivery Memo Number",
        :vehicle_no => "Vehicle No",
        :transporter => "Transporter"
      ),
      RequestDispatch.create!(
        :request_requisition_id => 2,
        :delivery_memo_number => "Delivery Memo Number",
        :vehicle_no => "Vehicle No",
        :transporter => "Transporter"
      )
    ])
  end

  it "renders a list of request_dispatches" do
    render
    assert_select "tr>td", :text => 2.to_s, :count => 2
    assert_select "tr>td", :text => "Delivery Memo Number".to_s, :count => 2
    assert_select "tr>td", :text => "Vehicle No".to_s, :count => 2
    assert_select "tr>td", :text => "Transporter".to_s, :count => 2
  end
end
