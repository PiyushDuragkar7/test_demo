require 'rails_helper'

RSpec.describe "request_requsitions/show", type: :view do
  before(:each) do
    @request_requsition = assign(:request_requsition, RequestRequsition.create!(
      :tender_id => 2,
      :item_request_requsition_id => 3,
      :total => 4.5
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/2/)
    expect(rendered).to match(/3/)
    expect(rendered).to match(/4.5/)
  end
end
