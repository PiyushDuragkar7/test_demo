require 'rails_helper'

RSpec.describe "request_requsitions/index", type: :view do
  before(:each) do
    assign(:request_requsitions, [
      RequestRequsition.create!(
        :tender_id => 2,
        :item_request_requsition_id => 3,
        :total => 4.5
      ),
      RequestRequsition.create!(
        :tender_id => 2,
        :item_request_requsition_id => 3,
        :total => 4.5
      )
    ])
  end

  it "renders a list of request_requsitions" do
    render
    assert_select "tr>td", :text => 2.to_s, :count => 2
    assert_select "tr>td", :text => 3.to_s, :count => 2
    assert_select "tr>td", :text => 4.5.to_s, :count => 2
  end
end
