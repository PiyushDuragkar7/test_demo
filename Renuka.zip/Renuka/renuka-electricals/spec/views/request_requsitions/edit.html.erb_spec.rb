require 'rails_helper'

RSpec.describe "request_requsitions/edit", type: :view do
  before(:each) do
    @request_requsition = assign(:request_requsition, RequestRequsition.create!(
      :tender_id => 1,
      :item_request_requsition_id => 1,
      :total => 1.5
    ))
  end

  it "renders the edit request_requsition form" do
    render

    assert_select "form[action=?][method=?]", request_requsition_path(@request_requsition), "post" do

      assert_select "input[name=?]", "request_requsition[tender_id]"

      assert_select "input[name=?]", "request_requsition[item_request_requsition_id]"

      assert_select "input[name=?]", "request_requsition[total]"
    end
  end
end
