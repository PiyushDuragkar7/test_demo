require 'rails_helper'

RSpec.describe "request_requsitions/new", type: :view do
  before(:each) do
    assign(:request_requsition, RequestRequsition.new(
      :tender_id => 1,
      :item_request_requsition_id => 1,
      :total => 1.5
    ))
  end

  it "renders new request_requsition form" do
    render

    assert_select "form[action=?][method=?]", request_requsitions_path, "post" do

      assert_select "input[name=?]", "request_requsition[tender_id]"

      assert_select "input[name=?]", "request_requsition[item_request_requsition_id]"

      assert_select "input[name=?]", "request_requsition[total]"
    end
  end
end
