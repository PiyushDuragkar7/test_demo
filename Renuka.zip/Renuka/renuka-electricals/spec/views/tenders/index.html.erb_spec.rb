require 'rails_helper'

RSpec.describe "tenders/index", type: :view do
  before(:each) do
    assign(:tenders, [
      Tender.create!(
        :tender_number => "Tender Number"
      ),
      Tender.create!(
        :tender_number => "Tender Number"
      )
    ])
  end

  it "renders a list of tenders" do
    render
    assert_select "tr>td", :text => "Tender Number".to_s, :count => 2
  end
end
