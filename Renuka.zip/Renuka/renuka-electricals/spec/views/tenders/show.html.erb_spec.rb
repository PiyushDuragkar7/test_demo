require 'rails_helper'

RSpec.describe "tenders/show", type: :view do
  before(:each) do
    @tender = assign(:tender, Tender.create!(
      :tender_number => "Tender Number"
    ))
  end

  it "renders attributes in <p>" do
    render
    expect(rendered).to match(/Tender Number/)
  end
end
