require 'rails_helper'

RSpec.describe "tenders/edit", type: :view do
  before(:each) do
    @tender = assign(:tender, Tender.create!(
      :tender_number => "MyString"
    ))
  end

  it "renders the edit tender form" do
    render

    assert_select "form[action=?][method=?]", tender_path(@tender), "post" do

      assert_select "input[name=?]", "tender[tender_number]"
    end
  end
end
