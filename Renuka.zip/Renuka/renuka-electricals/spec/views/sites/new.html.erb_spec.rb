require 'rails_helper'

RSpec.describe "sites/new", type: :view do
  before(:each) do
    assign(:site, Site.new(
      :tender_id => 1,
      :supervisor_id => 1,
      :contractor_id => 1
    ))
  end

  it "renders new site form" do
    render

    assert_select "form[action=?][method=?]", sites_path, "post" do

      assert_select "input[name=?]", "site[tender_id]"

      assert_select "input[name=?]", "site[supervisor_id]"

      assert_select "input[name=?]", "site[contractor_id]"
    end
  end
end
