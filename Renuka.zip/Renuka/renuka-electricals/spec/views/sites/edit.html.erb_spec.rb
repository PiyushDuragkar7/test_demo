require 'rails_helper'

RSpec.describe "sites/edit", type: :view do
  before(:each) do
    @site = assign(:site, Site.create!(
      :tender_id => 1,
      :supervisor_id => 1,
      :contractor_id => 1
    ))
  end

  it "renders the edit site form" do
    render

    assert_select "form[action=?][method=?]", site_path(@site), "post" do

      assert_select "input[name=?]", "site[tender_id]"

      assert_select "input[name=?]", "site[supervisor_id]"

      assert_select "input[name=?]", "site[contractor_id]"
    end
  end
end
