require 'rails_helper'

RSpec.describe "sites/index", type: :view do
  before(:each) do
    assign(:sites, [
      Site.create!(
        :tender_id => 2,
        :supervisor_id => 3,
        :contractor_id => 4
      ),
      Site.create!(
        :tender_id => 2,
        :supervisor_id => 3,
        :contractor_id => 4
      )
    ])
  end

  it "renders a list of sites" do
    render
    assert_select "tr>td", :text => 2.to_s, :count => 2
    assert_select "tr>td", :text => 3.to_s, :count => 2
    assert_select "tr>td", :text => 4.to_s, :count => 2
  end
end
