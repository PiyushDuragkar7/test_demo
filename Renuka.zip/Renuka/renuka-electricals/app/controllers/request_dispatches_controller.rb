class RequestDispatchesController < ApplicationController
  before_action :set_request_dispatch, only: [:show, :edit, :update, :destroy]

  # purpose : To show all request dispatched if super admin or admin 
  # updated by : VisInz
  # updated at : 08/05/2020
  def index
    if is_super_admin? || is_admin? || is_user?
      @request_dispatches = RequestDispatch.all
    else
      @request_dispatches = current_system_user.request_dispatchs
    end
  end

  # GET /request_dispatches/1
  # GET /request_dispatches/1.json
  def show  
  end

  # GET /request_dispatches/new
  def new
    @request_dispatch = RequestDispatch.new 
    @request_requisition = RequestRequsition.find(params[:id])
    if @request_requisition.tender.blank?
      flash[:notice] = "No tender availiable"
      redirect_to request_requsitions_path
    else
      if @request_requisition.site_id?
        get_tender = Site.where(id: @request_requisition.site_id)
      else
        get_tender = []
      end
      if get_tender.present? && @request_requisition.site_id?
        @site_name = get_tender[0].site_name
      else
        @site_name = nil
      end
    end
  end

  # purpose : To find request dispatch with params id nd to find request requisition of that dispatched request
  # updated by : VisInz
  # updated at : 08/05/2020
  def edit
    @request_dispatch = RequestDispatch.find(params[:id])
    @request_requisition = RequestRequsition.find(@request_dispatch.request_requsition_id)
  end

  # POST /request_dispatches
  # POST /request_dispatches.json
  def create
    #@@dispatch = true
    @request_dispatch = RequestDispatch.new(request_dispatch_params)
    respond_to do |format|
      # debugger
      if @request_dispatch.save
        # debugger
        create_dispatch_request(params[:request_disptach])
        #$dispatch = true
        format.html { redirect_to @request_dispatch, notice: 'Request dispatch was successfully created.' }
        format.json { render :show, status: :created, location: @request_dispatch }
      else
        # debugger
        format.html { render :new }
        format.json { render json: @request_dispatch.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /request_dispatches/1
  # PATCH/PUT /request_dispatches/1.json
  def update
    respond_to do |format|
      if @request_dispatch.update(request_dispatch_params)
        format.html { redirect_to @request_dispatch, notice: 'Request dispatch was successfully updated.' }
        format.json { render :show, status: :ok, location: @request_dispatch }
      else
        format.html { render :edit }
        format.json { render json: @request_dispatch.errors, status: :unprocessable_entity }
      end
    end
  end

  def quantity_update
    itm_dispatch = []
    ItemDispatch.all.each do |item_despatch|
      if item_despatch.request_dispatch.contractor_name == params[:contractor_name]
        itm_dispatch << item_despatch
      end 
    end
    @item  = Item.find_by(name: params[:item_name])
    @itm_dispatch_two = []
    itm_dispatch.each do |itemdis|
      if itemdis.item_id == @item.id
        @itm_dispatch_two << itemdis
      end 
    end
    @itm_dispatch_two.each do |itemdistwo|
      @result =  itemdistwo.update(used_quantity: params[:used_quantity.to_f])
    end
    if @result
      render json: { result: @itm_dispatch_two }
    end
  end

  # DELETE /request_dispatches/1
  # DELETE /request_dispatches/1.json
  def destroy
    @request_dispatch.destroy
    respond_to do |format|
      format.html { redirect_to request_dispatches_url, notice: 'Request dispatch was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_request_dispatch
    @request_dispatch = RequestDispatch.find(params[:id])
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def request_dispatch_params
    params.require(:request_dispatch).permit(:request_requsition_id, :delivery_memo_number, :delivery_date, :vehicle_no, :transporter, :user_id, :site_name, :contractor_name, :used_quantity)
  end

  # Update item quantity after dispatched items.
  def create_dispatch_request(params)
    params[:item_id].each do |item|
      index = params[:item_id].index(item)
      quantity = params[:quantity].values_at(index).first
      ItemDispatch.create(item_id: item , request_dispatch_id:  @request_dispatch.id, quantity: quantity.to_f)
      item_data = Item.find(item)
      qunatity = item_data.quantity.to_f - quantity.to_f
      item_data.update_columns(quantity: qunatity.to_f)
      request = @request_dispatch.request_requsition.item_request_requisitions.find_by_item_id(item)
      if (request.quantity.to_f == quantity.to_f)
        request.destroy
      else
        new_quant = request.quantity.to_f - quantity.to_f
        request.update_attributes(quantity:new_quant)
      end
    end
  end
end

