class ScsController < ApplicationController
  before_action :set_sc, only: [:show, :edit, :update, :destroy]

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To display all SC listing.
  # Updated By: SanWan
  # Updated On: 27/10/2020
  # Update Purpose : To show consumer name on index page using consumer_id.
  ##++
  def index
    @scs = Sc.all
    @consumer = Consumer.find(params[:consumer_id])
  end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To display single/ particular SC record .
  ##++
  def show
  end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To intialize @sc object.
  ##++
  def new
    @sc = Sc.new
    respond_to :js
  end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To create single SC record .
  ##++
  def create
    @sc = Sc.new(sc_params)
    if @sc.save
      respond_to :js
    else
      render 'new'
      respond_to :js
    end
  end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To update single/ particular SC record .
  ##++
  def edit
    respond_to :js
  end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To update single/ particular SC record .
  ##++
  def update
    @sc.update(sc_params)
    respond_to :js
  end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To delete single/ particular SC record .
  ##++
  def destroy
    @sc.destroy
    respond_to :js
  end

  private
  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To get single/ particular SC record by id.
  ##++
    def set_sc
      @sc = Sc.find(params[:id])
    end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To get parameters for SC to create SC record.
  ##++
    def sc_params
      params.require(:sc).permit(:description_of_material, :unit, :items_used, :consumer_id)
    end
end
