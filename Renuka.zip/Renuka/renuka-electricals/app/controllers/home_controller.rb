class HomeController < ApplicationController

  # purpose : To check current system user is signed or not, and it is super_admin or admin 
  # updated by : VisInz
  # updated at : 08/05/2020
  def index
    #if system_user_signed_in?
     # if is_super_admin? || is_admin? || is_user?
      #  redirect_to admin_index_path
      #else
       # redirect_to store_manager_index_url
      #end
   # end
  end
end