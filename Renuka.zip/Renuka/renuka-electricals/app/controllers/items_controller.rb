class ItemsController < ApplicationController
  before_action :set_item, only: [:show, :edit, :update, :destroy]
  # before_action :authenticate_admin_store
  include ApplicationHelper

  #purpose : To pass items with uniq names to index view
  #updated by : VisInz
  #updated at : 5/05/2020
  def index
    @items = Item.order(:name).pluck(:name).uniq
  end


  # GET /items/1
  # GET /items/1.json
  def show
  end


  # GET /items/new
  def new
    @supplier = Supplier.new
    @item = @supplier.items.build
  end

  # GET /items/1/edit
  def edit
    @item = Item.find(params[:id])
  end

  #purpose : To get item name from params and find item with that item name and update thier price with the price specified in params
  #updated by : VisInz
  #updated at : 5/05/2020
  def create
    begin
      params[:supplier][:items_attributes].each do |key,value|
        supplier = Supplier.find(params[:supplier][:supplier_id])
        value.delete("_destroy")
        item = value.permit!
        supplier.items.create!(item)
        Item.where(name: value['name']).update(price: value['price'])
      end
      redirect_to items_path, notice: 'Item was successfully created.'
    rescue Exception => e
      redirect_to new_item_path, notice: 'Please enter valid details'
    end
  end

  def supplier_create
    if params[:supplier_id].present?
      @supplier = Supplier.find(params[:supplier_id])
      @item = @supplier.items.create(item_params)
      redirect_to supplier_path(@supplier)
      respond_to do |format|
        if @item.save
          format.html { redirect_to @item, notice: 'Item was successfully created.' }
          format.json { render :show, status: :created, location: @item }
        else
          format.html { render :new }
          format.json { render json: @item.errors, status: :unprocessable_entity }
        end
      end
    else
      redirect_to items_path
    end
  end

  # PATCH/PUT /items/1
  # PATCH/PUT /items/1.json
  def update
    respond_to do |format|
      if item_params[:total_quantity].present?
        @item.quantity = item_params[:total_quantity]
        if @item.update(item_params)
          update_item_history(@item)
          format.html { redirect_to @item, notice: 'Item was successfully updated.' }
          format.json { render :show, status: :ok, location: @item }
        else
          format.html { render :edit }
          format.json { render json: @item.errors, status: :unprocessable_entity }
        end
      end
    end
  end

  # DELETE /items/1
  # DELETE /items/1.json
  def destroy
    @item.destroy
    respond_to do |format|
      format.html { redirect_to items_url, notice: 'Item was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def transaction_history
    @transaction_histories = TransactionHistory.all.order('created_at DESC').paginate(:page=>params[:page],per_page:20)
    respond_to do |format|
      format.html
      format.json
      format.pdf {
        render template: 'items/transaction_histories',
        pdf: 'Transaction_Histories'
      }
    end
  end

  def transaction_pdf
    @transaction_pdf_items = TransactionHistory.all.order('created_at DESC').paginate(:page=>params[:page_id],per_page:20)
    respond_to do |format|
      format.html
      format.json
      format.pdf {
        render template: 'items/transaction_histories',
        pdf: 'Transaction_Histories'
      }
    end
  end

  def item_history
    @item = Item.find(params[:id])
    @history = @item.histories
    respond_to do |format|
      format.html
      format.json
      format.pdf {
        render template: 'items/item_histories',
        pdf: 'Item_Histories'
      }
    end
  end

  #To get the pdf list of item histories
  def download
    @item = Item.find(params[:id])
    @history = @item.histories
    pdf = WickedPdf.new.pdf_from_string(render_to_string('items/item_histories_pdf', layout:item_history))
    send_data(pdf,
      filename: 'item_histories.pdf',
      type: 'application/pdf',
      disposition: 'attachment'
    )
  end

   #To get the pdf list of transaction histories
  def download_transaction_histroy
    pdf = WickedPdf.new.pdf_from_string(render_to_string('items/transaction_histories_pdf', layout: transaction_pdf))
    send_data(pdf,
      filename: 'transaction_histories.pdf',
      type: 'application/pdf',
      disposition: 'attachment'
    )
  end

  def item_contractor
    @contractors = User.where(designation: "Contractor")
  end

  ##--
  # Updated By: VisWan
  # Updated On: 17/09/2020
  # Purpose: To update the used Item count based on "pole schedule page" items_used total
  # and the locations where items used..
  ##++
  def dropdown
    @item_names = []
    @item_quantity = []
    items = []
    location = []
    @item_dispatch = ItemDispatch.all.uniq { |p| p.item_id }
    @item_dispatch.each do |item_dispatch|
      if item_dispatch.request_dispatch.contractor_name == params[:contractor_name]
        dispatched_items = ItemDispatch.all.where(item_id: item_dispatch.item_id).sum(:quantity)
        item_name = item_dispatch.item.name rescue nil
        begin
          # Find contractor and their consumers
          contractor =  User.find_by(first_name: params[:contractor_name])
          consumer = Consumer.where(user_id: contractor).pluck(:id)
          consumer.each do |consumer|
            # Get Items Used count from each sheet of pole schedule of consumer.
            dtc = Dtc.where(consumer_id: consumer).where(description_of_material: item_name)
            @dtc_item_used = @dtc_item_used.to_f + Dtc.where(id: dtc).sum(:items_used).to_f
            spcp = Spcp.where(consumer_id: consumer).where(description_of_material: item_name)
            @spcp_item_used = @spcp_item_used.to_f + Spcp.where(id: spcp).sum(:items_used).to_f
            sc = Sc.where(consumer_id: consumer).where(description_of_material: item_name)
            @sc_item_used = @sc_item_used.to_f + Sc.where(id: sc).sum(:items_used).to_f
            ht = Ht.where(consumer_id: consumer).where(description_of_material: item_name)
            @ht_item_used = @ht_item_used.to_f + Ht.where(id: ht).sum(:items_used).to_f
          end
          item_used_count = @dtc_item_used + @spcp_item_used + @sc_item_used + @ht_item_used
          location = Consumer.where(user_id: contractor).pluck(:location)
          items << {"name": item_name, "quantity": dispatched_items, "used_quantity": item_used_count, "location": location} if item_name.present?
        rescue
          item_used_count = 0
          location = "Not available"
          items << {"name": item_name, "quantity": dispatched_items, "used_quantity": item_used_count, "location": location}
        end
      end
    end
    render json: { items: items }.to_json
  end

  #purpose : To find item with the name which is provided in params
  #updated by : VisInz
  #updated at : 5/05/2020
  def item_details
    @items_details = Item.where(name: params[:name])
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_item
      @item = Item.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def item_params
      params.require(:item).permit(:name, :quantity, :price, :recorder_level, :add_quantity, :total_quantity, :supplier_id, :invoice_no, :date, :unit)
    end
end
