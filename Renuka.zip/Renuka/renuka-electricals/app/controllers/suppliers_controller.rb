class SuppliersController < ApplicationController
  before_action :set_supplier, only: [:show, :edit, :update, :destroy]

  # GET /suppliers
  # GET /suppliers.json
  def index
    @item = Item.new
    @suppliers = Supplier.all
    @items = Supplier.first.items rescue ""
  end

  # GET /suppliers/1
  # GET /suppliers/1.json
  def show
  end

  # GET /suppliers/new
  def new
    @supplier = Supplier.new
  end

  # GET /suppliers/1/edit
  def edit
    @show_sup = "/suppliers/#{params[:id]}"
  end

  # POST /suppliers
  # POST /suppliers.json
  def create
    @supplier = Supplier.new(supplier_params)

    respond_to do |format|
      if @supplier.save
        format.html { redirect_to @supplier, notice: 'Supplier was successfully created.' }
        format.json { render :show, status: :created, location: @supplier }
      else
        format.html { render :new }
        format.json { render json: @supplier.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /suppliers/1
  # PATCH/PUT /suppliers/1.json
  def update
    respond_to do |format|
      if @supplier.update(supplier_params)
        format.html { redirect_to @supplier, notice: 'Supplier was successfully updated.' }
        format.json { render :show, status: :ok, location: @supplier }
      else
        format.html { render :edit }
        format.json { render json: @supplier.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /suppliers/1
  # DELETE /suppliers/1.json
  def destroy
      if @supplier.orders.where(status: true).count == 0
        @supplier.destroy
        redirect_to suppliers_url, notice: 'Supplier was successfully destroyed.'
      else
        respond_to do |format|
        format.html { redirect_to suppliers_url, notice: 'Supplier was successfully destroyed.' }
        format.json { head :no_content }
      end
    end
  end

 def find_items
    @items = Item.where(supplier_id: params[:id])
    respond_to do |format|
      format.html do
        render partial: "supplier_items", object: @items 
      end
    end 
  end

  def find_supplier
    @supplier_name = Supplier.find(params[:id])
    render json: { response: @supplier_name, status: 200 }
  end
  
  def supplier_item_create
    @supplier = Supplier.find(params[:item][:supplier_id])
    @item = @supplier.items.create(item_params)
    @items =  @supplier.items
    respond_to do |format|
      format.js { render "supplier_items" }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_supplier
      @supplier = Supplier.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def supplier_params
      params.require(:supplier).permit(:name, :address, :office_address, :contact_person, :contact_number, :email, :pan_card_number, :gst_number,  items_attributes: [:id, :name, :quantity, :total_quantity, :price, :recorder_level, :_destroy, :unit])
    end
    
   def item_params
      params.require(:item).permit(:name,:total_quantity, :quantity, :price, :recorder_level, :unit)
    end
end