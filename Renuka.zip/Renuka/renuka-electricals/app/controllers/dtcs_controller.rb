class DtcsController < ApplicationController
  before_action :set_dtc, only: [:show, :edit, :update, :destroy]
  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To display all DTC listing.
  # Updated By: SanWan
  # Updated On: 27/10/2020
  # Update Purpose : To show consumer name on index page using consumer_id.
  ##++
  def index
    @dtcs = Dtc.all
    @consumer = Consumer.find(params[:consumer_id])
  end
  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To intialize @dtc object.
  ##++
  def new
    @dtc = Dtc.new
    respond_to :js
  end
  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To display single/ particular DTC record .
  ##++
  def show
  end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To create single DTC record .
  ##++
  def create
    @dtc = Dtc.new(dtc_params)
    if @dtc.save
      respond_to :js
    else
      render 'new'
      respond_to :js
    end
  end

  # ##--
  # # Created By: VisWan
  # # Created On: 27/08/2020
  # # Purpose: To update single/ particular DTC record .
  # ##++
  def edit
    respond_to :js
  end
  # ##--
  # # Created By: VisWan
  # # Created On: 27/08/2020
  # # Purpose: To update single/ particular DTC record .
  # ##++
  def update
    @dtc.update(dtc_params)
    respond_to :js
  end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To delete single/ particular DTC record .
  ##++
  def destroy
    @dtc.destroy
    respond_to :js
  end

  private
  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To get single/ particular DTC record by id.
  ##++
    def set_dtc
      @dtc = Dtc.find(params[:id])
    end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To get parameters for DTC to create DTC record.
  ##++
    def dtc_params
      params.require(:dtc).permit(:description_of_material, :unit, :items_used, :consumer_id)
    end
end
