class StoreManagerController < ApplicationController
  # purpose : To change authenticate_user! to authenticate_system_user! 
  # updated by : VisInz
  # updated at : 08/05/2020
  before_action :authenticate_system_user!
  def index
  end
end
