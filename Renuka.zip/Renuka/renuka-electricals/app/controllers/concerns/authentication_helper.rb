module AuthenticationHelper
  extend ActiveSupport::Concern

  # purpose : To return true if current user is super admin
  # updated by : VisInz
  # updated at : 08/05/2020
  def is_super_admin?
    current_system_user.is_super_admin
  end

  # purpose : To return true if current user is admin
  # updated by : VisInz
  # updated at : 08/05/2020
  def is_admin?
    if current_system_user.is_super_admin == false && current_system_user.status == "Active"  
      return true
    end
  end
end