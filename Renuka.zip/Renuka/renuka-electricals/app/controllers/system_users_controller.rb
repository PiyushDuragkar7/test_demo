class SystemUsersController < ApplicationController

	include Devise
  before_action :authenticate_system_user!
  
  #User Management for contractors
  # purpose :  To show list of admin system users
  # updated by : VisInz
  # updated at : 10/05/2020
  def admin_index
    @admin_users = SystemUser.where(is_super_admin: false )
  end

  # purpose : Add new admin system user.
  # updated by : VisInz
  # updated at : 10/05/2020
  def new_admin
    @admin_user = SystemUser.new
  end

  # purpose : To create new admin system user
  # updated by : VisInz
  # updated at : 10/05/2020
  def create_admin
    @admin_user = SystemUser.new(system_user_params)
    if @admin_user.save
      flash[:notice] = 'Admin System User is added successfully'
      redirect_to system_users_admin_index_path
    else
      render 'new_admin'
      flash[:alert] = @admin_user.errors.full_messages
    end
  end

  # purpose : To delete admin system user
  # updated by : VisInz
  # updated at : 10/05/2020
  def delete_admin
    admin_user = SystemUser.find(params[:id])
    if admin_user.destroy
      flash[:notice]= 'Admin System User is removed successfully'
    end
    respond_to do |format|
      format.html { redirect_to system_users_admin_index_path }
      format.json { head :no_content }
    end
  end

  # purpose : To edit admin system user
  # updated by : VisInz
  # updated at : 10/05/2020
  def edit_admin
    @admin_user = SystemUser.find(params[:id])
  end

  # purpose : To update data of admin system user
  # updated by : VisInz
  # updated at : 10/05/2020
  def update_admin
    @admin_user = SystemUser.find(params[:id])
    if @admin_user.update_attributes(system_user_params)
      flash[:notice] = 'Admin System User is updated successfully'
     redirect_to system_users_admin_index_path
    else
      render 'edit_admin'
      flash[:alert] = @admin_user.errors.full_messages.first
    end
  end

  # purpose : Admin system user params
  # updated by : VisInz
  # updated at : 10/05/2020
  # User update params
  def system_user_params
    params.require(:system_user).permit(:email, :password, :password_confirmation, :is_super_admin, :status, :role_id)
  end
end