class ConsumersController < ApplicationController
before_action :set_consumer, only: [:show, :edit, :update, :destroy]

  def index
   @consumers = Consumer.all
   respond_to do |format|
   format.html
   format.pdf do
     render pdf: "index.pdf",
     template: "consumers/index_pdf.html.erb"
    end
   end
 end

  def show
		@consumer = Consumer.find(params[:id])
	end


  def new
		@consumer = Consumer.new
		@contractors = User.all.where(designation: "Contractor")
	end

  def edit
  end
  ##--
  # Updated By: VisWan
  # Updated On: 27/08/2020
  # Purpose: To update "pole schedule" column with pole schedule page link.
  ##++
  def create
    @consumer = Consumer.new(consumer_params)
    link = url_for :controller => 'consumers', :action => 'pole_schedule'
    @consumer.update_attribute( :pole_schedule, link )
    respond_to do |format|
      if @consumer.save
        format.html { redirect_to @consumer, notice: 'Consumer was successfully created.' }
        format.json { render :show, status: :created, location: @consumer }
      else
        format.html { render :new }
        format.json { render json: @consumer.errors, status: :unprocessable_entity }
      end
    end
  end

   def update
    respond_to do |format|
      if @consumer.update(consumer_params)
        format.html { redirect_to @consumer, notice: 'Consumer was successfully updated.' }
        format.json { render :show, status: :ok, location: @consumer }
      else
        format.html { render :edit }
        format.json { render json: @consumer.errors, status: :unprocessable_entity }
      end
    end
  end

   def destroy
    @consumer.destroy
    respond_to do |format|
      format.html { redirect_to consumers_url, notice: 'Consumer was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  ##--
  # Updated By: SanWan
  # Updated On: 27/10/2020
  # Purpose: To make available consumer id to pole schedule and pass it to other links on pole scehdule page.
  ##++
  def pole_schedule
    @consumer = Consumer.find(params[:consumer])
  end

	private

	def set_consumer
      @consumer = Consumer.find(params[:id])
    end

	def consumer_params
		params.require(:consumer).permit(:name, :dc, :location, :tender_id, :user_id, :pole_schedule)
  end
end
