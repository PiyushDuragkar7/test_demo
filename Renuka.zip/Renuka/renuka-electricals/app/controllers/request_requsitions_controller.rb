class RequestRequsitionsController < ApplicationController
  before_action :set_request_requsition, only: [:show, :edit, :update, :destroy]

  # purpose : To list of all request requisition if super admin or admin
  # updated by : VisInz
  # updated at : 08/05/2020
  def index
    item_ids = ItemDispatch.all.pluck(:id)
    if is_super_admin? || is_admin? || is_user?
      @request_requsitions = RequestRequsition.all
    else
      @request_requsitions = current_system_user.request_requsitions.where.not(id: item_ids)
    end
  end

  # GET /request_requsitions/1
  # GET /request_requsitions/1.json
  def show
  end

  # purpose : To find users with designation contractor
  # updated by : VisInz
  # updated at : 08/05/2020
  def new
    @request_requsition = RequestRequsition.new
    @contractors = User.all.where(designation: "Contractor")
  end

  # GET /request_requsitions/1/edit
  def edit
  end

  def change_site
    site = Site.where("tender_id = #{params[:tender_id]}")
    render json: { response: site, status: 200 }
  end

  # POST /request_requsitions
  # POST /request_requsitions.json
  def create    
    @request_requsition = RequestRequsition.new(request_requsition_params)
    respond_to do |format|
      if @request_requsition.save
        create_item_request(params[:items]) if params[:items].present?
        format.html { redirect_to @request_requsition, notice: 'Request requsition was successfully created.' }
        format.json { render :show, status: :created, location: @request_requsition }
      else
        format.html { render :new }
        format.json { render json: @request_requsition.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /request_requsitions/1
  # PATCH/PUT /request_requsitions/1.json
  def update
    respond_to do |format|
      if @request_requsition.update(request_requsition_params)
        format.html { redirect_to @request_requsition, notice: 'Request requsition was successfully updated.' }
        format.json { render :show, status: :ok, location: @request_requsition }
      else
        format.html { render :edit }
        format.json { render json: @request_requsition.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /request_requsitions/1
  # DELETE /request_requsitions/1.json
  def destroy
    @request_requsition.destroy
    respond_to do |format|
      format.html { redirect_to request_requsitions_url, notice: 'Request requsition was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def item_details
    @item = Item.find(params[:name]) unless params[:name].blank?
    if @item.quantity.to_f >= params[:quantity].to_f
      @total = (@item.price * params[:quantity].to_f).round(2) unless @item.nil?
     render json: { response: [@item.name, @item.price, params[:quantity].to_f.round(2), @total, @item.id], status: 200 }
    else
    render json: {status: 400, response: @item.quantity.to_f }
   end
 end

 #  def item_details
 #  items = Item.where(name: params[:name])
 #  tq = items.pluck(:quantity).sum.to_f
 #  item = items.first
 #  if tq.to_f >= params[:quantity].to_f      
 #    @total = item.price * params[:quantity].to_f unless items.nil?
 #    render json: { response: [item.name, item.price, params[:quantity].to_f, @total, item.id], status: 200 }
 #  else
 #    render json: {status: 400, response: @item.quantity.to_f }
 #  end
 # end

  def item_name
    item = Item.find(params[:id]) unless params[:id].blank?
    render json: { response: item.name, status: 200 }
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_request_requsition
      @request_requsition = RequestRequsition.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def request_requsition_params
      params.require(:request_requsition).permit(:tender_id, :item_request_requsition_id, :total, :user_id, :site_id)
    end

    # Save all item request and quantity in database as per hash object.
    def create_item_request(params)
      params.split(",").each do |items|
        item_id = items.split(",")[0].split(":").first.scan(/\d+/).first.to_i
        quantity = items.split(",")[0].split(":").last.remove("}]").to_f
        ItemRequestRequisition.create(item_id: item_id , request_requsition_id:  @request_requsition.id, quantity: quantity.to_f)
      end
    end
end