  class SitesController < ApplicationController
    before_action :set_site, only: [:show, :edit, :update, :destroy]
    # before_action :authenticate_admin_store, except: [:index, :all_contractors, :show]
    # GET /sites
    # GET /sites.json

    # purpose : To show all sites if super admin or admin
    # updated by : VisInz
    # updated at : 08/05/2020
    def index
      if is_super_admin? || is_admin? || is_user?
        @sites = Site.all
      else
        @sites = Site.where(contractor_id: current_user.id)
      end
    end

    # GET /sites/1
    # GET /sites/1.json
    def show
    end

    # GET /sites/new
    # purpose : To show all users in dropdown on view and to implement many to maany association between user and site
    # updated by : VisInz
    # updated at : 08/05/2020
    def new
      @site = Site.new
      @all_users = User.all
      @site_user = @site.users.build
    end

    # GET /sites/1/edit
    # purpose : To show all users in dropdown on edit view
    # updated by : VisInz
    # updated at : 08/05/2020
    def edit
      @all_users = User.all
      @site_user = @site.users
      @show_site = "/sites/#{params[:id]}"
    end

    # POST /sites
    # POST /sites.json

    # purpose : To save multiple users for a site
    # updated by : VisInz
    # updated at : 08/05/2020
    def create
      @site = Site.new(site_params)
      @site.users = User.find(params[:users][:id].reject { |id| id.empty? })
      respond_to do |format|
        if @site.save
          format.html { redirect_to @site, notice: 'Site was successfully created.' }
          format.json { render :show, status: :created, location: @site }
        else
          format.html { render :new }
          format.json { render json: @site.errors, status: :unprocessable_entity }
        end
      end
    end

    # PATCH/PUT /sites/1
    # PATCH/PUT /sites/1.json
    # purpose : To update  users assigned to a site
    # updated by : VisInz
    # updated at : 08/05/2020
    def update
      respond_to do |format|
        if @site.update(site_params)
          @site.users.destroy_all
          @site.users = User.find(params[:users][:id].reject { |id| id.empty? }) 
          format.html { redirect_to @site, notice: 'Site was successfully updated.' }
          format.json { render :show, status: :ok, location: @site }
        else
          format.html { render :edit }
          format.json { render json: @site.errors, status: :unprocessable_entity }
        end
      end
    end

    # Show all contractor related to sites of current user
    def all_contractors
      # contractor_ids = Site.where(supervisor_id: current_system_user.id).map(&:contractor_id)
      # @contractors = User.where('id in (?)', contractor_ids)
      @contractors = User.where(designation: "Contractor")
    end

    # DELETE /sites/1
    # DELETE /sites/1.json
    def destroy
      @site.destroy
      respond_to do |format|
        format.html { redirect_to sites_url, notice: 'Site was successfully destroyed.' }
        format.json { head :no_content }
      end
    end

    private
      # Use callbacks to share common setup or constraints between actions.
      def set_site
        @site = Site.find(params[:id])
      end

      # Never trust parameters from the scary internet, only allow the white list through.
      # purpose : To remove contractor_id and supervisor_id
      # updated by : VisInz
      # updated at : 08/05/2020
      def site_params
        params.require(:site).permit(:tender_id, :site_name)
      end
  end