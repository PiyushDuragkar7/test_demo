class ApplicationController < ActionController::Base
  helper_method :is_super_admin?, :is_admin? , :is_user?

  include AuthenticationHelper
  before_action :authenticate_system_user!
  protected

  # purpose : To check signed in user is super admin or admin    
  # updated by : VisInz
  # updated at : 5/05/2020
  def after_sign_in_path_for(resource)
    if is_super_admin? || is_admin? || is_user?
      flash[:notice] = 'Successfully logged in'
      return admin_index_url
    else
      flash[:notice] = 'Your account status is inactive by admin, Please contact to admin'
      return root_url
    end
  end

  # purpose : To check user is super_admin or not
  # updated by : VisInz
  # updated at : 5/05/2020
  #def authorise_super_admin_user
  # purpose : To check user is super_admin or not by role_name
  # updated by : nehagcryp
  # updated at : 29/06/2020
  def is_super_admin?
    if current_system_user.role.role_name  == "super_admin" && current_system_user.status == "Active"
      return true
    else
      return false
    end
  end

  # purpose : To check user is admin or not
  # updated by : VisInz
  # updated at : 5/05/2020
  #def authorise_admin
  # purpose : To check user is is_admin or not by role_name
  # updated by : nehagcryp
  # updated at : 29/06/2020
  def is_admin?
    if current_system_user.role.role_name  == "admin" && current_system_user.status == "Active"
      return true
    else
      return false
    end
  end

  #def authorise_user
  # purpose : To check user is is_user or not by role_name
  # updated by : nehagcryp
  # updated at : 29/06/2020
  def is_user?
      if current_system_user.role.role_name  == "user" && current_system_user.status == "Active"
      return true
    else
      return false
    end
  end
end
