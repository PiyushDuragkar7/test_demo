class AdminController < ApplicationController
  def index
  end

  #User Management for contractors
  # purpose :  To show list of users based on designation not on role_id
  # updated by : VisInz
  # updated at : 08/05/2020
  def users
    @users = User.where(designation: params[:designation] )
    @link = request.original_url.split('=')
    session.delete(session["user_link"])
    session["user_link"] = @link[1] == 'contractor' ? "./users?designation=contractor" : @link[1] == 'supervisor' ? "./users?designation=supervisor" : "./users?designation=store_manager" 
  end

  #Add new user for admin.
  def new_user
    @user = User.new
  end

  #Create new user
  # purpose : To change redirection after save based on designation instead of role
  # updated by : VisInz
  # updated at : 08/05/2020
  def create_user
    @user = User.new(user_params)
    if @user.save
      flash[:notice] = 'New user is added successfully'
      redirect_to admin_users_path(designation: @user.designation)
    else
      render 'new_user'
      flash[:alert] = @user.errors.full_messages
    end
  end

  # purpose : To change redirection after delete based on designation instead of role
  # updated by : VisInz
  # updated at : 08/05/2020
  def delete_user
    user = User.find(params[:id])
    if user.destroy
      flash[:notice]= 'User is removed successfully'
    end
    respond_to do |format|
      format.html { redirect_to admin_users_path(designation: user.designation)}
      format.json { head :no_content }
    end
  end

  # purpose : To check user designation instead of its role 
  # updated by : VisInz
  # updated at : 08/05/2020
  def edit_user
    @user = User.find(params[:id])
    @user_link = "./users?designation=#{@user.designation.downcase}"
  end

  # purpose : To change redirection after update based on designation instead of role
  # updated by : VisInz
  # updated at : 08/05/2020
  def update_user
    @user = User.find(params[:id])
    if @user.update_attributes(user_params)
      flash[:notice]= 'User is updated successfully'
      redirect_to admin_users_path(designation: @user.designation)
    else
      render 'edit_user'
      flash[:alert] = @user.errors.full_messages.first
    end
  end

  # purpose : To remove email, password, password_confirmation and merged role_id from params
  # updated by : VisInz
  # updated at : 08/05/2020
  # User update params
  def user_params
    params.require(:user).permit(:first_name, :last_name, :email, :designation, :contact_number, :address)
  end
end
