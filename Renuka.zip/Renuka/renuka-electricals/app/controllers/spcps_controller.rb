class SpcpsController < ApplicationController
  before_action :set_spcp, only: [:show, :edit, :update, :destroy]

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To display all SPCP listing.
  # Updated By: SanWan
  # Updated On: 27/10/2020
  # Update Purpose : To show consumer name on index page using consumer_id.
  ##++
  def index
    @consumer = Consumer.find(params[:consumer_id])
    @spcps = Spcp.all
   
  end


  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To display single/ particular SPCP record .
  ##++
  def show
  end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To intialize @spcp object.
  ##++
  def new
    @spcp = Spcp.new
    respond_to :js
  end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To create single SPCP record .
  ##++
  def create
    @spcp = Spcp.new(spcp_params)
    if @spcp.save
      respond_to :js
    else
      render 'new'
      respond_to :js
    end
  end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To update single/ particular SPCP record .

  def edit
    respond_to :js
  end

  def update
    @spcp.update(spcp_params)
    respond_to :js
  end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To delete single/ particular SPCP record .
  ##++
  def destroy
    @spcp.destroy
    respond_to :js
  end

  private
  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To get single/ particular SPCP record by id.
  ##++
    def set_spcp
      @spcp = Spcp.find(params[:id])
    end

  ##--
  # Created By: VisWan
  # Created On: 27/08/2020
  # Purpose: To get parameters for SPCP to create SPCP record.
  ##++
    def spcp_params
      params.require(:spcp).permit(:description_of_material, :unit, :items_used, :consumer_id)
    end
end
