module TendersHelper
end
