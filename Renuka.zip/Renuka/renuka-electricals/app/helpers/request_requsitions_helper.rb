module RequestRequsitionsHelper

	def item_ids
	  if @request_requsitions.tender.present?
	    request = @request_requsitions.tender.tender_number
	  else 
      flash[:success] = "No tender availiable"
  	end
  end
end
