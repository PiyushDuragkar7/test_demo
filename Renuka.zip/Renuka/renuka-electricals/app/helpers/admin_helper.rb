module AdminHelper
  def get_user_count
    User.count
  end
end
