module ApplicationHelper

  def update_item_history(item)
    item.histories.create(count: item.add_quantity.to_f, invoice_no: item.invoice_no, date: @item.date, quantity: item.quantity)
  end

  #Return role name depending on user
  def all_roles
    if is_admin?
      Role.where('name not in (?)', ['admin']).map { |column| [column.name.camelize , column.id]}
    else
      Role.where('name not in (?)', ['admin', 'store_manager']).map { |column| [column.name.camelize , column.id]}
    end
  end

  # purpose : This helper will calculate similar items values and return them on view
  # updated by : VisInz
  # updated at : 5/05/2020
  def item_calculations(item_name)
    issue_quantity = []
    items = Item.where(name: item_name)
    previous_quantity = (items.pluck(:total_quantity).compact.sum.to_f - items.pluck(:add_quantity).compact.sum.to_f).round(2)
    added_quantity = (items.pluck(:add_quantity).compact.sum.to_f).round(2)
    items.each do |item_dis|
      issue_quantity << item_dis.item_dispatchs.pluck(:quantity).inject(0){|sum,x| sum + x.to_f}
    end
    issue_quantities = (issue_quantity.compact.sum).round(2)
    total_quantity = items.pluck(:quantity).inject(0){|sum,x| sum + x.to_f.round(2)}
    price = items.last.price
    unit = items.last.unit
    return [previous_quantity, added_quantity, issue_quantities, total_quantity, price, unit]
  end
  
  # purpose : To find site users with their designation and add comma between them 
  # updated by : VisInz
  # updated at : 08/05/2020
  def site_supervisors(site)
    site.users.where(designation: "Supervisor").pluck(:first_name).map(&:inspect).join(', ').gsub!('"', '')
  end

  def site_contractors(site)
    site.users.where(designation: "Contractor").pluck(:first_name).map(&:inspect).join(', ').gsub!('"', '')
  end

  def supervisor_role
    @site.users.where(designation: "Supervisor")
  end

  def contractor_role
    @site.users.where(designation: "Contractor")
  end

  def designation
    return params[:designation].camelize
  end

  def user_designation
    return params[:user_designation]
  end

  def request_requisition_dispatch(items)
    items.item.item_request_requisitions
  end

  def dispatched_request_id
    @request_dispatch.request_requsition_id
  end

  def site_supervisors_full_name(site)
    supervisors_arr = []
    site.users.where(designation: "Supervisor").each do |s_name|
      supervisors_arr << "#{s_name.first_name} #{s_name.last_name}"
    end
    return supervisors_arr.join(', ')
  end

  def site_contractors_full_name(site)
    contractors_arr = []
    site.users.where(designation: "Contractor").each do |c_name|
      contractors_arr << "#{c_name.first_name} #{c_name.last_name}"
    end
    return contractors_arr.join(', ')
  end
end
