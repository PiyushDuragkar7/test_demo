class ItemRequestRequisition < ApplicationRecord
  belongs_to :item
  belongs_to :request_requsition

  validates_format_of :quantity, :with =>  /\A^[0-9 .]+$\Z/
end
