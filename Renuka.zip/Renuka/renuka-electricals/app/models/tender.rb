class Tender < ApplicationRecord
  has_one :site
  has_many :request_requisitions
  has_many :consumers
end
