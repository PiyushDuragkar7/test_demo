class Supplier < ApplicationRecord
  has_many :purchase_orders
  has_many :orders
  has_many :items, inverse_of: :supplier
  accepts_nested_attributes_for :items, reject_if: :all_blank, allow_destroy: true

  validates :email, presence: true, format: { with: /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\z/i }
  validates_format_of :contact_person, with:  /\A[a-zA-Z ]+\Z/
  validates_format_of :contact_number, :with =>  /\A^[0-9\- \,\s]+$\z/ , :message => "Only positive number without spaces are allowed", :length => { :minimum => 3 ,:maximum => 15 }
end