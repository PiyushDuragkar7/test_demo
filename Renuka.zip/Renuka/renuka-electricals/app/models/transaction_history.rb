class TransactionHistory < ApplicationRecord
end
