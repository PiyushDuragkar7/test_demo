class Item < ApplicationRecord
  has_many :purchase_orders
  has_many :orders
  has_many :histories, dependent: :destroy
  belongs_to :supplier, :inverse_of => :items
  has_many :item_request_requisitions
  has_many :request_requisitions, through: :item_request_requisitions
  has_many :item_dispatchs
  has_many :request_dispatchs, through: :item_dispatchs

  validates_format_of :name, :with =>  /\A^[a-zA-Z0-9 \-\/*.,'()]+$\Z/, :message => "Please enter valid item name"
  validates_format_of :quantity, :with =>  /\A^[0-9 .]+$\Z/
  # purpose : To capitalize item name before creating item
  # updated by : VisInz
  # updated at : 08/05/2020
  # before_create -> { capitalize_item_name }
  # def capitalize_item_name
  #   self.name = self.name.capitalize
  # end
  


  before_create :capitalize_item_name
  def capitalize_item_name
   self.name = self.name.capitalize
  end

  after_create -> { create_item_history }

  def create_item_history
   self.histories.create(count: self.quantity, invoice_no: self.invoice_no, quantity: self.quantity, date: self.date, item_id: self.id)
  end


  after_save :create_transaction_history_create_and_update
  def create_transaction_history_create_and_update
    
    if self.add_quantity.present?
     TransactionHistory.create(name: self.name, quantity: self.add_quantity, 
                              supp_cont_name: self.supplier.name, color: true, 
                              date: self.date ,invoice_no: self.invoice_no)
    else
      TransactionHistory.create( name: self.name, quantity: self.quantity, 
                              supp_cont_name: self.supplier.name, color: true, 
                              date: self.date ,invoice_no: self.invoice_no)
    end
  end  
end



