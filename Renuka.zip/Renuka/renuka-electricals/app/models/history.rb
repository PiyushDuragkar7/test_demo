class History < ApplicationRecord
  belongs_to :item
end
