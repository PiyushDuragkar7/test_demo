class RequestDispatch < ApplicationRecord
  belongs_to :request_requsition
  has_many :items, through: :item_dispatchs
  belongs_to :user
  has_many :item_dispatchs
end
