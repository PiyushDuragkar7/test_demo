class Sc < ApplicationRecord
  belongs_to :consumer
end
