class RequestRequsition < ApplicationRecord
  has_many :item_request_requisitions
  has_many :items, through: :item_request_requisitions
  belongs_to :tender
  belongs_to :user
  has_one :request_dispatch
  validates_presence_of :total, message: 'Please add item.'

   def user_name
    @user_name ||= user.present? ? "#{user.first_name} #{user.last_name}" : "Not available" 
   end
end
