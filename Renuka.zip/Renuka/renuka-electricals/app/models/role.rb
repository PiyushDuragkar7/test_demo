class Role < ApplicationRecord
  has_many :system_users
  validates :role_name, uniqueness:true
end
