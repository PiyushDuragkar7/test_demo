class Ht < ApplicationRecord
  belongs_to :consumer
end
