class Dtc < ApplicationRecord
  belongs_to :consumer
end
