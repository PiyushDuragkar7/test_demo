class User < ApplicationRecord
  # purpose : To remove association with role table, To remove devise and to add many to many association between site and user
  # updated by : VisInz
  # updated at : 08/05/2020  
  has_and_belongs_to_many :sites
  has_many :request_requsitions
  has_many :request_dispatchs
  has_many :consumers
  validates :email, presence: true, uniqueness: true, format: { with: /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\z/i }
  validates_format_of :first_name, :last_name, with:  /\A[a-z]+\Z/i
  validates_format_of :contact_number, :with =>  /\d[0-9]\)*\z/ , :message => "Only positive number without spaces are allowed", :length => { :minimum => 10, :maximum => 15 }

  def full_name
    "#{first_name} #{last_name}"
  end
end