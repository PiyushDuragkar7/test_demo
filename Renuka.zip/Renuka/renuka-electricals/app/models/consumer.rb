class Consumer < ApplicationRecord
 belongs_to :tender
 belongs_to :user
 has_many :dtcs
 has_many :spcps
 has_many :scs
 has_many :hts

 def user_name
   @user_name ||= user.present? ? "#{user.first_name} #{user.last_name}" : "Not available"
  end
end
