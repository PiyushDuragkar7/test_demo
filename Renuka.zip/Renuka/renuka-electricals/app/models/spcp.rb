class Spcp < ApplicationRecord
  belongs_to :consumer
end
