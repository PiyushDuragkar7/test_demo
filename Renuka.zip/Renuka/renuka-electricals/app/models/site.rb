class Site < ApplicationRecord
  # purpose : To remove validation of supervisor_id and contractor_id and to add many to many association between site and user   
  # updated by : VisInz
  # updated at : 08/05/2020  
  belongs_to :tender
  has_and_belongs_to_many :users
  validates_presence_of :tender_id
end