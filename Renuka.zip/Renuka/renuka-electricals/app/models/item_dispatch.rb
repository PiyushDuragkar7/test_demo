class ItemDispatch < ApplicationRecord
  belongs_to :request_dispatch
  belongs_to :item

  after_create -> { dispatch_transaction_history }
  def dispatch_transaction_history
  	TransactionHistory.create( name: self.item.name, quantity: self.quantity,
    						 supp_cont_name: self.request_dispatch.contractor_name, 
    						 date: self.request_dispatch.delivery_date,  color: false, 
    						 invoice_no: self.request_dispatch.delivery_memo_number)
  end
 end
