$(function () {
  $('#lstFruits-one').multiselect({
      includeSelectAllOption: true
  });

  $('#lstFruits-two').multiselect({
      includeSelectAllOption: true
  });
});