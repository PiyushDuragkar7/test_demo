$("#item-request-container form").submit(function() {
  var irr = $("#item_request_requisitions-count").text();
  for (i = 0; i < irr; i++) {
    var qty = parseFloat($("#exampleDispatchQuantity-"+i).val());
    var rqty = parseFloat($("#ReqQuantity-"+i).text());
    var iqry = parseFloat($("#ItemQuantity-"+i).text());
  
    if(qty > rqty){
      alert("Dispatch Quantity "+qty+" is greater than requested quantity");
      return false;
    }
  }
});


