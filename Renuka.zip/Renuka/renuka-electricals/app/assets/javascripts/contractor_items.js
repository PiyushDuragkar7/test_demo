$( document ).ready(function() {
  $("#contractor-dropdown").change(function() {
    $('#dataTable').find('#append-rows td').remove();
    contractor_name = $("#contractor-dropdown").val();
    $.ajax({
      type: 'GET',
      url: '/dropdown',
      data: { contractor_name: contractor_name },
      success: function(data) {
        jQuery.each(data.items, function( i, val ) {
          if(val.used_quantity == null){
            val.used_quantity = 0;
            remaining_quantity = val.quantity;
          }
          else{
            remaining_quantity = val.quantity - val.used_quantity
          }
          $("#append-rows").append("<tr id="+ i +"><td>"+ val.name +"</td><td>"+ val.quantity +"</td><td>"+ val.used_quantity +"</td><td>"+ remaining_quantity +"</td><td>"+ val.location +"</td><td><button class='btn btn-primary open-popup'>Edit</button></td></tr>");
        });
      },
      error: function(data) {
      }
    });

    //Open Edit popup modal code
    $(document).on('click', '.open-popup', function(){
      item_name = $(this).parent().parent().find('td:first')[0].innerHTML;
      item_quantity = $(this).parent().parent().find('td')[1].innerHTML;
      $('#itemName').attr('placeholder', item_name)
      $('#itemQuantity').attr('placeholder', item_quantity)
      $('#myModal').modal('show');
    });
    $(".close-popup").click(function(){
      $('#myModal').modal('hide');
    });
    // click on savebutton Get value of remaning quantity.
    $(document).ready(function(){
      $(".savebutton").click(function() {
        var item_name = $("#itemName").attr('placeholder');
        var item_quantity = $("#itemQuantity").attr('placeholder');
        var used_quantity = $("#usedQuantity").val();
        var contractor_name = $("#contractor-dropdown").val();
          $.ajax({
            type: 'GET',
            url: '/quantity_update',
            data: {item_name: item_name, item_quantity: item_quantity, used_quantity: used_quantity,contractor_name: contractor_name},
            success: function(data) {
            $("#myModal").modal('hide');
            location.reload();
          },
           error: function(data) {
          }
        });
      });
    });
  });
});