$( document ).on('turbolinks:load', function() {

  var itemList = [];

  $('#AddItems').click(function(e) { //on add input button click
    e.preventDefault();
    var item = $("#ItemValue").val();
     var quantity = $("#exampleQuantity").val();
     $.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: "/request_requsitions/item_details",
        dataType: "json",
        data: {'name': item, 'quantity': quantity},
        success: function (data) {
            if(data.status == 200){
            item = {}
            item [data.response[4]] = data.response[2];
            itemList.push(item);
            appendResultToTable(data, JSON.stringify(itemList));
            $("#ItemValue option[value="+ data.response[4] + "]").remove();
            $("#exampleQuantity").val('');
            var total = parseInt($("#exampleTotal").val()) || 0;
            var total_price = parseInt(total) + parseInt(data.response[3]);
            $("#exampleTotal").val(total_price);
          }else{
            alert("Requested stock is not available, available stock is " + data.response ) ;
          }
          console.log(JSON.stringify(itemList));

        }
      });
    });

  // Show Selected item list with remove link.
  function appendResultToTable(data, items) {
    var id = data.response[4]
    $("#item_fields").append(
      "<tr id="+ id+">" +
        "<td>"+ data.response[0] +"</td>" +
        "<td> "+ data.response[1] +"</td>" +
        "<td> "+ data.response[2] + "</td>" +
        "<td id='total'> "+ data.response[3] +"</td>" +
        "<td> "+ "<a href='#' class='remove_field'>Remove</a>" +"</td>" +
      "</tr>"
    );

    $("#ItemValue").append("<input type=hidden name='items'value='>"+items +"'</input>");
  }

  $('#item_fields').on("click",".remove_field", function(e){ //user click on remove text
    e.preventDefault();
    var trid = $(this).closest('tr').attr('id');
    var current_price = $(this).parent().parent().find('#total').text();
    var price = parseInt($("#exampleTotal").val()) || 0;
    var total_price = parseInt(price) - parseInt(current_price);
    $.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: "/request_requsitions/item_name",
        dataType: "json",
        data: {'id': trid},
        success: function (data) {
          $("#ItemValue").append($("<option></option>").attr("value", trid).text(data.response));
          $("#exampleTotal").val(total_price);
        }
      });
      $(this).closest('tr').remove();
      delete itemList[trid];
      console.log(itemList);
  });

 });