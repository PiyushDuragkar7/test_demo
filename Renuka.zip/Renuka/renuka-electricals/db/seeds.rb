# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)
# roles = %w[admin store_manager contractor supervisor]

# roles.each do |role|
#   Role.create(name: role)
# end
# puts '4 roles created.'

#Create admin user
# User.create!(first_name: 'Admin', last_name: 'User', email: 'admin@gmail.com', password: '123456', role_id: Role.find_by(name: 'admin').id, confirmed_at: Time.zone.now, contact_number: 0712245224, address: 'Nagpur')
# puts '1 admin created.'

# Role.create!(role_name: "super_admin")
# Role.create!(role_name: "admin")
# Role.create!(role_name: "user")

# puts "Three roles created"

# SystemUser.create!(email: 'superadmin1@gmail.com', password: '123456', role_id: 1)
# puts '1 Super admin system user created.'

# Tender.create!(tender_number: '98777',address: 'NGP',zone: 'olo', circle: 'ccoo', division: 'ddiv', sub_division: 'subDIV', tender_value: '5656', total_customers: '45', total_dtc_location: 'goa')
# puts '1 tender is created'

# User.create!(first_name: 'RAm', last_name: 'rai', email: 'R2@gmail.com', contact_number: '4444', address: 'ring road')

# Consumer.create!(tender_id: '1', user_id: '1', name: 'goko', dc: 'gololo', location: 'Raipur')

##--
# Created By: VisWan
# Created On: 7/09/2020
# Purpose: To import DTC sheet fixed data provided by client.
##++
require 'csv' 

CSV.foreach(Rails.root.join('lib/seeds/dtc.csv'), headers: true) do |row|
  Dtc.create!( {
  	id: row["id"],
    description_of_material: row["description_of_material"], 
    unit: row["unit"],
    items_used: row["items_used"], 
    consumer_id: row["consumer_id"]
  } ) 
  puts "There are now #{Dtc.count} rows in the DTC table"
end

##--
# Created By: VisWan
# Created On: 7/09/2020
# Purpose: To import SPCP sheet fixed data provided by client.
##++
CSV.foreach(Rails.root.join('lib/seeds/spcp.csv'), headers: true) do |row|
  Spcp.create!( {
  	id: row["id"],
    description_of_material: row["description_of_material"], 
    unit: row["unit"],
    items_used: row["items_used"], 
    consumer_id: row["consumer_id"]
  } ) 
  puts "There are now #{Spcp.count} rows in the DTC table"
end

##--
# Created By: VisWan
# Created On: 8/09/2020
# Purpose: To import SC sheet fixed data provided by client.
##++
CSV.foreach(Rails.root.join('lib/seeds/sc.csv'), headers: true) do |row|
  Sc.create!( {
  	id: row["id"],
    description_of_material: row["description_of_material"], 
    unit: row["unit"],
    items_used: row["items_used"], 
    consumer_id: row["consumer_id"]
  } ) 
  puts "There are now #{Sc.count} rows in the DTC table"
end
##--
# Created By: VisWan
# Created On: 8/09/2020
# Purpose: To import HT sheet fixed data provided by client.
##++
CSV.foreach(Rails.root.join('lib/seeds/ht.csv'), headers: true) do |row|
  Ht.create!( {
  	id: row["id"],
    description_of_material: row["description_of_material"], 
    unit: row["unit"],
    items_used: row["items_used"], 
    consumer_id: row["consumer_id"]
  } ) 
  puts "There are now #{Ht.count} rows in the DTC table"
end