# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 2020_08_27_131622) do

  create_table "consumers", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "name"
    t.string "dc"
    t.string "location"
    t.integer "tender_id"
    t.integer "user_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "pole_schedule"
  end

  create_table "dtcs", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "description_of_material"
    t.string "unit"
    t.string "items_used"
    t.bigint "consumer_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["consumer_id"], name: "index_dtcs_on_consumer_id"
  end

  create_table "histories", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "count"
    t.bigint "item_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "invoice_no"
    t.datetime "date"
    t.string "quantity"
    t.index ["item_id"], name: "index_histories_on_item_id"
  end

  create_table "hts", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "description_of_material"
    t.string "unit"
    t.string "items_used"
    t.bigint "consumer_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["consumer_id"], name: "index_hts_on_consumer_id"
  end

  create_table "item_dispatches", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.bigint "request_dispatch_id"
    t.bigint "item_id"
    t.string "quantity"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "used_quantity"
    t.index ["item_id"], name: "index_item_dispatches_on_item_id"
    t.index ["request_dispatch_id"], name: "index_item_dispatches_on_request_dispatch_id"
  end

  create_table "item_request_requisitions", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.bigint "item_id"
    t.bigint "request_requsition_id"
    t.string "quantity"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["item_id"], name: "index_item_request_requisitions_on_item_id"
    t.index ["request_requsition_id"], name: "index_item_request_requisitions_on_request_requsition_id"
  end

  create_table "items", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "name"
    t.string "quantity"
    t.float "price"
    t.string "recorder_level"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "add_quantity"
    t.string "total_quantity"
    t.bigint "supplier_id"
    t.string "invoice_no"
    t.date "date"
    t.string "unit"
    t.index ["supplier_id"], name: "index_items_on_supplier_id"
  end

  create_table "orders", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "quantity"
    t.boolean "status"
    t.date "expire_at"
    t.bigint "item_id"
    t.bigint "supplier_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["item_id"], name: "index_orders_on_item_id"
    t.index ["supplier_id"], name: "index_orders_on_supplier_id"
  end

  create_table "purchase_orders", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "order_number"
    t.integer "item_id"
    t.integer "supplier_id"
    t.float "total"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "request_dispatches", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.bigint "request_requsition_id"
    t.bigint "user_id"
    t.string "delivery_memo_number"
    t.date "delivery_date"
    t.string "vehicle_no"
    t.string "transporter"
    t.float "total"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "site_name"
    t.string "contractor_name"
    t.index ["request_requsition_id"], name: "index_request_dispatches_on_request_requsition_id"
    t.index ["user_id"], name: "index_request_dispatches_on_user_id"
  end

  create_table "request_requsitions", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.integer "tender_id"
    t.integer "user_id"
    t.float "total"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "site_id"
  end

  create_table "roles", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "role_name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "scs", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "description_of_material"
    t.string "unit"
    t.string "items_used"
    t.bigint "consumer_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["consumer_id"], name: "index_scs_on_consumer_id"
  end

  create_table "sites", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.bigint "tender_id"
    t.integer "supervisor_id"
    t.integer "contractor_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "site_name"
    t.index ["tender_id"], name: "index_sites_on_tender_id"
  end

  create_table "sites_users", id: false, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.bigint "site_id", null: false
    t.bigint "user_id", null: false
  end

  create_table "spcps", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "description_of_material"
    t.string "unit"
    t.string "items_used"
    t.bigint "consumer_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["consumer_id"], name: "index_spcps_on_consumer_id"
  end

  create_table "suppliers", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "name"
    t.text "address"
    t.string "contact_person"
    t.string "contact_number"
    t.string "email"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "pan_card_number"
    t.string "gst_number"
    t.string "office_address"
  end

  create_table "system_users", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.boolean "is_super_admin", default: false
    t.string "status"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "role_id"
    t.index ["email"], name: "index_system_users_on_email", unique: true
    t.index ["reset_password_token"], name: "index_system_users_on_reset_password_token", unique: true
  end

  create_table "tenders", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "tender_number"
    t.text "address"
    t.string "zone"
    t.string "circle"
    t.string "division"
    t.string "sub_division"
    t.string "tender_value"
    t.integer "total_customers"
    t.integer "total_dtc_location"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "transaction_histories", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "name"
    t.string "quantity"
    t.string "supp_cont_name"
    t.boolean "color"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "date"
    t.string "invoice_no"
    t.string "count"
  end

  create_table "users", options: "ENGINE=InnoDB DEFAULT CHARSET=utf8", force: :cascade do |t|
    t.string "first_name", default: "", null: false
    t.string "last_name", default: "", null: false
    t.string "email", default: "", null: false
    t.string "contact_number", default: "", null: false
    t.text "address", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "designation"
    t.index ["email"], name: "index_users_on_email", unique: true
  end

  add_foreign_key "dtcs", "consumers"
  add_foreign_key "histories", "items"
  add_foreign_key "hts", "consumers"
  add_foreign_key "orders", "items"
  add_foreign_key "orders", "suppliers"
  add_foreign_key "scs", "consumers"
  add_foreign_key "spcps", "consumers"
end
