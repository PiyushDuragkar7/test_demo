class SiteNameToSites < ActiveRecord::Migration[5.2]
  def change
  	add_column :sites, :site_name, :integer
  end
end
