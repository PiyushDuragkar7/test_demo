class ChangeAddQuantityToBeStringInItemDispatches < ActiveRecord::Migration[5.2]
  def change
  	change_column :item_dispatches, :quantity, :string
  end
end
