class RemoveColumnsFromUsers < ActiveRecord::Migration[5.2]
  def change
  	remove_column :users, :encrypted_password
  	remove_column :users, :role_id
  	remove_column :users, :reset_password_token
  	remove_column :users, :reset_password_sent_at
  	remove_column :users, :remember_created_at
  	remove_column :users, :confirmation_token
  	remove_column :users, :confirmed_at
  	remove_column :users, :confirmation_sent_at
  	remove_column :users, :unconfirmed_email
  end
end