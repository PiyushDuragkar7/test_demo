class CreateItemDispatches < ActiveRecord::Migration[5.2]
  def change
    create_table :item_dispatches do |t|
      t.belongs_to :request_dispatch
      t.belongs_to :item
      t.integer :quantity

      t.timestamps
    end
  end
end
