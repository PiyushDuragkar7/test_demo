class CreateSites < ActiveRecord::Migration[5.2]
  def change
    create_table :sites do |t|
      t.references :tender
      t.integer :supervisor_id
      t.integer :contractor_id

      t.timestamps
    end
  end
end
