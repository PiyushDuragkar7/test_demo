class RenameRemainingQuantitytoaddQuantity < ActiveRecord::Migration[5.2]
  def change
    change_table :items do |t|
      t.rename :remaining_quantity, :add_quantity
    end
  end
end
