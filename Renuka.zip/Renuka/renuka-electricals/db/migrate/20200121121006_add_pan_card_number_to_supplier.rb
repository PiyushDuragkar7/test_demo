class AddPanCardNumberToSupplier < ActiveRecord::Migration[5.2]
  def change
     add_column :suppliers, :pan_card_number, :string
     add_column :suppliers, :gst_number, :string
  end
end
