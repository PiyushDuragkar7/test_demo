class CreateRequestDispatches < ActiveRecord::Migration[5.2]
  def change
    create_table :request_dispatches do |t|
      t.belongs_to :request_requsition
      t.belongs_to :user
      t.string :delivery_memo_number
      t.date :delivery_date
      t.string :vehicle_no
      t.string :transporter
      t.float :total

      t.timestamps
    end
  end
end
