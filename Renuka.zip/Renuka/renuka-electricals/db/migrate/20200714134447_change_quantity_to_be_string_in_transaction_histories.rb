class ChangeQuantityToBeStringInTransactionHistories < ActiveRecord::Migration[5.2]
  def change
  	  change_column :transaction_histories, :quantity, :string
  end
end
