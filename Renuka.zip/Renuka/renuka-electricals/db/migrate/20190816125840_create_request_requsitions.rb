class CreateRequestRequsitions < ActiveRecord::Migration[5.2]
  def change
    create_table :request_requsitions do |t|
      t.integer :tender_id
      t.integer :user_id
      t.float :total

      t.timestamps
    end
  end
end
