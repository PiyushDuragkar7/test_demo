class ChangeContactNumberToBeStringInSuppliers < ActiveRecord::Migration[5.2]
  def change
  	change_column :suppliers, :contact_number, :string
  end
end