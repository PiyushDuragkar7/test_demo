class CreateDtcs < ActiveRecord::Migration[5.2]
  def change
    create_table :dtcs do |t|
      t.string :description_of_material
      t.string :unit
      t.string :items_used
      t.references :consumer, foreign_key: true

      t.timestamps
    end
  end
end
