class AddPoleScheduleToConsumers < ActiveRecord::Migration[5.2]
  def change
    add_column :consumers, :pole_schedule, :string
  end
end
