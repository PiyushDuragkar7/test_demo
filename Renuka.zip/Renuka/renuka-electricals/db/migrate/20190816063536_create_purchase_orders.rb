class CreatePurchaseOrders < ActiveRecord::Migration[5.2]
  def change
    create_table :purchase_orders do |t|
      t.string :order_number
      t.integer :item_id
      t.integer :supplier_id
      t.float :total

      t.timestamps
    end
  end
end
