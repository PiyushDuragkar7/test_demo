class AddTotalQuantityToItem < ActiveRecord::Migration[5.2]
  def change
    add_column :items, :total_quantity, :integer
  end
end
