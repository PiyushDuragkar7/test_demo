class ChangeSiteNameToBeStringInSites < ActiveRecord::Migration[5.2]
  def change
  	change_column :sites, :site_name, :string
  end
end
