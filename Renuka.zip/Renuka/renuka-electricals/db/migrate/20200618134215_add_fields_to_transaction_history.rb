class AddFieldsToTransactionHistory < ActiveRecord::Migration[5.2]
  def change
  	add_column :transaction_histories, :date, :datetime
    add_column :transaction_histories, :invoice_no, :string
  end
end
