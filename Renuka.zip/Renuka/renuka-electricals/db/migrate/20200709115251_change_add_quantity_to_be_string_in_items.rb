class ChangeAddQuantityToBeStringInItems < ActiveRecord::Migration[5.2]
  def change
  	change_column :items, :add_quantity, :string
  end
end
