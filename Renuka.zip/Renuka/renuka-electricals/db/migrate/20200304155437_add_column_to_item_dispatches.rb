class AddColumnToItemDispatches < ActiveRecord::Migration[5.2]
  def change
  	add_column :item_dispatches, :used_quantity, :string
  end
end
