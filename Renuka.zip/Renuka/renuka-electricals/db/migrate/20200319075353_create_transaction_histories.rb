class CreateTransactionHistories < ActiveRecord::Migration[5.2]
  def change
    create_table :transaction_histories do |t|
      t.string :name
      t.integer :quantity
      t.string :supp_cont_name
      t.boolean :color

      t.timestamps
    end
  end
end
