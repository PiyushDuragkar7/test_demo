class ChangeColumnName < ActiveRecord::Migration[5.2]
  def change
  	 rename_column :roles, :name, :role_name
  end
end
