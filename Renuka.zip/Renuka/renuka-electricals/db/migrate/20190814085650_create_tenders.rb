class CreateTenders < ActiveRecord::Migration[5.2]
  def change
    create_table :tenders do |t|
      t.string :tender_number
      t.text :address
      t.string :zone
      t.string :circle
      t.string :division
      t.string :sub_division
      t.string :tender_value
      t.integer :total_customers
      t.integer :total_dtc_location

      t.timestamps
    end
  end
end
