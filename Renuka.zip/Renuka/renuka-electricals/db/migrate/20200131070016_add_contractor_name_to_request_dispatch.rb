class AddContractorNameToRequestDispatch < ActiveRecord::Migration[5.2]
  def change
    add_column :request_dispatches, :contractor_name, :string
  end
end
