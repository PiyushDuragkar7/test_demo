class ChangeCountToBeStringInHistories < ActiveRecord::Migration[5.2]
  def change
  	change_column :histories, :count, :string
  end
end
