class AddFieldsToItem < ActiveRecord::Migration[5.2]
  def change
  	add_column :items, :date, :string
    add_column :items, :invoice_no, :string
  end
end
