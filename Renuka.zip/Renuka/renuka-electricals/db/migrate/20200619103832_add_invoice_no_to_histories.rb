class AddInvoiceNoToHistories < ActiveRecord::Migration[5.2]
  def change
    add_column :histories, :invoice_no, :string
  end
end
