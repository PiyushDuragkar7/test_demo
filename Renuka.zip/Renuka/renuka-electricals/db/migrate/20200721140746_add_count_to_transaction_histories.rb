class AddCountToTransactionHistories < ActiveRecord::Migration[5.2]
  def change
    add_column :transaction_histories, :count, :string
  end
end
