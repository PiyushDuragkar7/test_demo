class ChangeAddQuantityToBeStringInItemRequestRequisitions < ActiveRecord::Migration[5.2]
  def change
  	change_column :item_request_requisitions, :quantity, :string
  end
end
