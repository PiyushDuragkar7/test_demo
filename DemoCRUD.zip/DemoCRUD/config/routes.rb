Rails.application.routes.draw do
resources :players
#get "players" =>"players#login"
#get"players" =>"players#index"
#get"players/new" =>"players#new"
#post"players" =>"players#create"
#get "players/:id" =>"players#show" ,as :player  #to generate path for show
#get "players/:id/edit" =>"players#edit" ,as :player  #to generate path for show
#patch "players/:id" =>"players#update"
#delete "players/:id" =>"players#destroy"
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
