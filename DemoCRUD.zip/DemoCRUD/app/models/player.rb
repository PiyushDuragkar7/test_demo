class Player < ApplicationRecord
    validates :first_name, :last_name, :gender, :league, :email, presence:true
end
