class ApplicationMailer < ActionMailer::Base
  default from: 'piyushdurugkar7@gmail.com'
  layout 'mailer'
end
