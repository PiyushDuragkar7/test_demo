class AddColumnToPlayer < ActiveRecord::Migration[6.0]
  def change
    add_column :players, :gender, :string
    add_column :players, :league, :string
    add_column :players, :email, :string
  end
end
